export interface ParkourPrompt {
  id: string;
  title: string;
  description: string;
  cameraAngle: string;
  difficulty: 'Hard' | 'Extreme' | 'Death Wish';
  duration: string;
  hashtags: string[];
}