import React, { useEffect, useRef, useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';

interface AmbientSoundProps {
  soundscape: 'Windy' | 'Industrial' | 'Urban' | 'Silence';
}

const AmbientSound: React.FC<AmbientSoundProps> = ({ soundscape }) => {
  const [isMuted, setIsMuted] = useState(false);
  const audioCtxRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const sourceNodesRef = useRef<AudioScheduledSourceNode[]>([]);

  // Initialize Audio Context
  useEffect(() => {
    // Browsers require a user gesture to start audio context.
    // We assume this component mounts after the user clicks "Generate".
    const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioContextClass) return;

    const ctx = new AudioContextClass();
    const gain = ctx.createGain();
    gain.connect(ctx.destination);
    
    audioCtxRef.current = ctx;
    masterGainRef.current = gain;

    return () => {
      ctx.close();
    };
  }, []);

  // Handle Mute/Unmute
  useEffect(() => {
    if (masterGainRef.current) {
      const now = audioCtxRef.current?.currentTime || 0;
      masterGainRef.current.gain.setTargetAtTime(isMuted ? 0 : 0.3, now, 0.1);
    }
  }, [isMuted]);

  // Handle Soundscape Change
  useEffect(() => {
    if (!audioCtxRef.current || !masterGainRef.current) return;
    
    const ctx = audioCtxRef.current;
    
    // Resume context if suspended (common browser policy)
    if (ctx.state === 'suspended') {
      ctx.resume();
    }

    // Stop previous sounds
    sourceNodesRef.current.forEach(node => {
      try { node.stop(); } catch (e) {}
    });
    sourceNodesRef.current = [];

    if (soundscape === 'Silence') return;

    // Create Noise Buffer
    const bufferSize = ctx.sampleRate * 2; // 2 seconds of noise
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    
    if (soundscape === 'Windy') {
      // Pink Noise approximation
      let b0, b1, b2, b3, b4, b5, b6;
      b0 = b1 = b2 = b3 = b4 = b5 = b6 = 0.0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + white * 0.0555179;
        b1 = 0.99332 * b1 + white * 0.0750759;
        b2 = 0.96900 * b2 + white * 0.1538520;
        b3 = 0.86650 * b3 + white * 0.3104856;
        b4 = 0.55000 * b4 + white * 0.5329522;
        b5 = -0.7616 * b5 - white * 0.0168980;
        data[i] = b0 + b1 + b2 + b3 + b4 + b5 + b6 + white * 0.5362;
        data[i] *= 0.11; // compensate for gain
        b6 = white * 0.115926;
      }
    } else if (soundscape === 'Urban' || soundscape === 'Industrial') {
      // Brown Noise approximation
      let lastOut = 0;
      for (let i = 0; i < bufferSize; i++) {
        const white = Math.random() * 2 - 1;
        data[i] = (lastOut + (0.02 * white)) / 1.02;
        lastOut = data[i];
        data[i] *= 3.5; 
      }
    }

    const noiseSource = ctx.createBufferSource();
    noiseSource.buffer = buffer;
    noiseSource.loop = true;

    const filter = ctx.createBiquadFilter();
    
    if (soundscape === 'Windy') {
      // High pass + varying low pass for wind
      filter.type = 'lowpass';
      filter.frequency.value = 400;
      
      // Wind gust modulation
      const osc = ctx.createOscillator();
      osc.type = 'sine';
      osc.frequency.value = 0.1; // Slow gusts
      const oscGain = ctx.createGain();
      oscGain.gain.value = 300; // Modulate filter by +/- 300Hz
      
      osc.connect(oscGain);
      oscGain.connect(filter.frequency);
      osc.start();
      sourceNodesRef.current.push(osc);
    } else if (soundscape === 'Industrial') {
      // Low drone
      filter.type = 'lowpass';
      filter.frequency.value = 150;
      
      // Add a metallic hum
      const osc = ctx.createOscillator();
      osc.type = 'sawtooth';
      osc.frequency.value = 50; // 50Hz mains hum
      const oscGain = ctx.createGain();
      oscGain.gain.value = 0.05;
      osc.connect(oscGain);
      oscGain.connect(masterGainRef.current);
      osc.start();
      sourceNodesRef.current.push(osc);
    } else if (soundscape === 'Urban') {
      // Distant rumble
      filter.type = 'lowpass';
      filter.frequency.value = 200;
    }

    noiseSource.connect(filter);
    filter.connect(masterGainRef.current);
    
    noiseSource.start();
    sourceNodesRef.current.push(noiseSource);

  }, [soundscape]);

  return (
    <button 
      onClick={() => setIsMuted(!isMuted)}
      className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-700 text-xs font-mono uppercase text-zinc-400 hover:text-white hover:border-zinc-500 transition-colors"
    >
      {isMuted ? <VolumeX className="w-3 h-3" /> : <Volume2 className="w-3 h-3 text-red-500 animate-pulse" />}
      {isMuted ? 'Audio Off' : `Sound: ${soundscape}`}
    </button>
  );
};

export default AmbientSound;