import React, { useState } from 'react';
import { ParkourPrompt } from '../types';
import { AlertTriangle, Eye, Copy, Check, Hash } from 'lucide-react';

interface PromptCardProps {
  prompt: ParkourPrompt;
}

const PromptCard: React.FC<PromptCardProps> = ({ prompt }) => {
  const [copiedSection, setCopiedSection] = useState<string | null>(null);

  const getDifficultyColor = (diff: string) => {
    switch (diff) {
      case 'Death Wish': return 'text-red-600 border-red-600 bg-red-950/30';
      case 'Extreme': return 'text-orange-500 border-orange-500 bg-orange-950/30';
      default: return 'text-yellow-500 border-yellow-500 bg-yellow-950/30';
    }
  };

  const handleCopy = async (text: string, section: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedSection(section);
      setTimeout(() => setCopiedSection(null), 2000);
    } catch (err) {
      console.error('Failed to copy text: ', err);
    }
  };

  return (
    <div className="w-full max-w-2xl bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden shadow-2xl relative group">
      {/* Decorative top bar */}
      <div className="h-2 w-full bg-gradient-to-r from-yellow-600 via-red-600 to-purple-600"></div>
      
      <div className="p-8">
        <div className="flex justify-between items-start mb-6">
          <div>
            <span className={`inline-flex items-center px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider border ${getDifficultyColor(prompt.difficulty)}`}>
              <AlertTriangle className="w-3 h-3 mr-2" />
              {prompt.difficulty}
            </span>
            <span className="ml-3 text-zinc-500 text-xs font-mono uppercase tracking-widest">
              DUR: {prompt.duration}
            </span>
          </div>
          <div className="text-zinc-500 flex items-center gap-2 text-sm font-mono">
            <Eye className="w-4 h-4" />
            {prompt.cameraAngle}
          </div>
        </div>

        {/* Title Section with Copy Button */}
        <div className="flex items-center gap-4 mb-4 group/title">
          <h2 className="text-4xl md:text-5xl font-bold text-white brand-font tracking-wide uppercase leading-none">
            {prompt.title}
          </h2>
          <button
            onClick={() => handleCopy(prompt.title, 'title')}
            className="opacity-100 md:opacity-0 md:group-hover/title:opacity-100 transition-all duration-200 p-2 text-zinc-600 hover:text-white rounded-md hover:bg-zinc-800"
            title="Copy Title"
          >
            {copiedSection === 'title' ? <Check className="w-5 h-5 text-green-500" /> : <Copy className="w-5 h-5" />}
          </button>
        </div>
        
        {/* Description Section with Copy Button */}
        <div className="relative group/text mb-6">
          <p className="text-lg text-zinc-300 leading-relaxed font-light border-l-2 border-zinc-700 pl-4 pr-10">
            "{prompt.description}"
          </p>
          <button
            onClick={() => handleCopy(prompt.description, 'description')}
            className="absolute top-0 right-0 p-2 text-zinc-600 hover:text-white transition-all duration-200 rounded-md hover:bg-zinc-800"
            title="Copy Description"
          >
            {copiedSection === 'description' ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </button>
        </div>

        {/* Hashtags Section with Copy Button */}
        <div className="flex flex-wrap items-center gap-2 pt-4 border-t border-zinc-800">
          <button
            onClick={() => handleCopy(prompt.hashtags.join(' '), 'hashtags')}
            className="mr-2 p-1.5 text-zinc-600 hover:text-white rounded-md hover:bg-zinc-800 transition-colors"
            title="Copy Hashtags"
          >
            {copiedSection === 'hashtags' ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
          </button>
          <Hash className="w-4 h-4 text-zinc-500" />
          {prompt.hashtags.map((tag, index) => (
            <span key={index} className="text-blue-400 hover:text-blue-300 transition-colors text-sm font-medium cursor-pointer">
              {tag}
            </span>
          ))}
        </div>
      </div>
      
      {/* Background Texture Effect */}
      <div className="absolute inset-0 pointer-events-none opacity-5 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-white to-transparent"></div>
    </div>
  );
};

export default PromptCard;