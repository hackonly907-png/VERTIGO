import React from 'react';
import { Play, Download } from 'lucide-react';

interface VideoResultProps {
  videoUrl: string;
}

const VideoResult: React.FC<VideoResultProps> = ({ videoUrl }) => {
  return (
    <div className="mt-8 w-full max-w-sm mx-auto animate-in fade-in slide-in-from-bottom-8 duration-700">
      <div className="relative rounded-xl overflow-hidden border border-zinc-700 shadow-2xl bg-black aspect-[9/16]">
        <video 
          src={videoUrl} 
          controls 
          autoPlay 
          loop 
          className="w-full h-full object-cover"
        />
        
        <div className="absolute top-4 right-4 bg-black/60 backdrop-blur-sm px-2 py-1 rounded text-xs font-mono text-white border border-white/10">
          AI GENERATED
        </div>
      </div>

      <div className="mt-4 flex justify-center">
        <a 
          href={videoUrl} 
          download="vertigo_parkour.mp4"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 text-zinc-400 hover:text-white transition-colors text-sm uppercase tracking-wider"
        >
          <Download className="w-4 h-4" /> Download Footage
        </a>
      </div>
    </div>
  );
};

export default VideoResult;