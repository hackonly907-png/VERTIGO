import { GoogleGenAI, Type } from "@google/genai";
import { ParkourPrompt } from "../types";

// Helper to ensure we have a key or prompt for one
const getAiClient = async (): Promise<GoogleGenAI> => {
  if (window.aistudio) {
    const hasKey = await window.aistudio.hasSelectedApiKey();
    if (!hasKey) {
      await window.aistudio.openSelectKey();
    }
  }
  // The key is injected into process.env.API_KEY by the environment after selection
  return new GoogleGenAI({ apiKey: process.env.API_KEY });
};

const RESPONSE_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING, description: "A viral, short, all-caps video title (e.g. 'DEATH DROP 400FT?!')" },
    description: { type: Type.STRING, description: "A vivid visual description of the action, environment, and danger. Suitable for video generation AI." },
    cameraAngle: { type: Type.STRING, description: "e.g., POV, GoPro, Bodycam" },
    difficulty: { type: Type.STRING, enum: ["Hard", "Extreme", "Death Wish"] },
    duration: { type: Type.STRING, description: "The estimated duration of the action, e.g., '8s'" },
    hashtags: { 
      type: Type.ARRAY, 
      items: { type: Type.STRING },
      description: "List of 6-8 viral hashtags including #parkour #pov"
    }
  },
  required: ["title", "description", "cameraAngle", "difficulty", "duration", "hashtags"]
};

export const generateScaryPrompt = async (customInput?: string): Promise<ParkourPrompt> => {
  const ai = await getAiClient();
  
  const systemInstruction = `
    You are an extreme sports director and social media expert specializing in hyper-realistic, high-stakes parkour and freerunning POV videos. 
    Your goal is to generate terrifying, vertigo-inducing prompt descriptions for video generation that look like raw bodycam or GoPro footage.
    
    CRITICAL INSTRUCTIONS:
    - Focus heavily on TEXTURE (crumbling concrete, rusty metal, slippery glass, wet rooftop).
    - Describe the LIGHTING (harsh sunlight, flickering neon, foggy morning, golden hour shadows).
    - Emphasize the CAMERA MOVEMENT (violent shaking, stabilizing, wind buffeting, fisheye distortion).
    - The perspective must be FIRST PERSON (POV) looking down at feet or hands on edges.
    - Mention visible body parts (legs dangling, hands gripping, sneakers sliding).
    - Focus on 'death wish' scenarios: Cranes, skyscrapers, abandoned cooling towers.
    - Generate a viral, clickbait-style TITLE (Name) for the video.
    - Generate a list of 6-8 relevant, high-traffic HASHTAGS.
    
    The prompt must describe a scene that lasts approximately 8-9 seconds.
  `;

  let promptText = "Generate a new random, hyper-realistic, scary parkour scenario with title and hashtags.";
  if (customInput && customInput.trim()) {
    promptText += ` \n\nIMPORTANT USER REQUEST: The scenario MUST take place in or feature: "${customInput}". Integrate this seamlessly into the scary parkour context.`;
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: promptText,
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: RESPONSE_SCHEMA
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  const data = JSON.parse(text);
  return {
    id: crypto.randomUUID(),
    ...data
  };
};

export const generateSequelPrompt = async (previousPrompt: ParkourPrompt): Promise<ParkourPrompt> => {
  const ai = await getAiClient();

  const systemInstruction = `
    You are an extreme sports director.
    Generate a DIRECT SEQUEL / CONTINUATION to the specific parkour scenario provided below.
    
    PREVIOUS SCENARIO CONTEXT:
    Title: "${previousPrompt.title}"
    Action: "${previousPrompt.description}"
    
    INSTRUCTIONS:
    - The runner has just survived the previous stunt. Where do they go next?
    - Start the description immediately after the previous action ended.
    - ESCALATE THE DANGER. If they jumped a gap, now they are sliding down a crane or being chased.
    - Maintain the same visual style (POV, gritty, textured).
    - Generate a NEW Title that implies a sequel or next level (e.g. "ESCAPING THE ROOF", "LEVEL 2: THE CRANE").
    - Keep the "Death Wish" energy.
    
    The prompt must describe a scene that lasts approximately 8-9 seconds.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: "Generate the sequel prompt now.",
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: RESPONSE_SCHEMA
    }
  });

  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  const data = JSON.parse(text);
  return {
    id: crypto.randomUUID(),
    ...data
  };
};