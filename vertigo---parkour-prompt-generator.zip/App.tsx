import React, { useState } from 'react';
import { generateScaryPrompt, generateSequelPrompt } from './services/geminiService';
import { ParkourPrompt } from './types';
import PromptCard from './components/PromptCard';
import { Zap, Skull, RefreshCw, FastForward, MapPin } from 'lucide-react';

const App: React.FC = () => {
  const [currentPrompt, setCurrentPrompt] = useState<ParkourPrompt | null>(null);
  const [isGeneratingText, setIsGeneratingText] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [customInput, setCustomInput] = useState('');

  const handleGeneratePrompt = async () => {
    try {
      setError(null);
      setIsGeneratingText(true);
      const prompt = await generateScaryPrompt(customInput);
      setCurrentPrompt(prompt);
    } catch (e: any) {
      setError(e.message || "Failed to generate prompt. Please check your API key.");
    } finally {
      setIsGeneratingText(false);
    }
  };

  const handleGenerateSequel = async () => {
    if (!currentPrompt) return;
    try {
      setError(null);
      setIsGeneratingText(true);
      const prompt = await generateSequelPrompt(currentPrompt);
      setCurrentPrompt(prompt);
    } catch (e: any) {
      setError(e.message || "Failed to generate sequel.");
    } finally {
      setIsGeneratingText(false);
    }
  };

  const handleReset = () => {
    setCurrentPrompt(null);
    setError(null);
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8 relative overflow-x-hidden">
      
      {/* Background Gradients */}
      <div className="fixed top-[-20%] left-[-10%] w-[50%] h-[50%] bg-red-900/10 blur-[120px] rounded-full pointer-events-none" />
      <div className="fixed bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-blue-900/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Header */}
      <header className="w-full max-w-5xl flex justify-between items-center mb-16 z-10">
        <div className="flex items-center gap-2 cursor-pointer" onClick={handleReset}>
          <div className="w-10 h-10 bg-white text-black flex items-center justify-center rounded-sm">
            <Skull className="w-6 h-6" />
          </div>
          <div>
            <h1 className="text-3xl font-bold leading-none tracking-tighter text-white">VERTIGO</h1>
            <p className="text-xs text-zinc-500 tracking-[0.2em] uppercase">AI Parkour Generator</p>
          </div>
        </div>
        
        <div className="hidden md:block">
            <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" className="text-xs text-zinc-600 hover:text-zinc-400 transition-colors">
            POWERED BY GEMINI
            </a>
        </div>
      </header>

      {/* Main Content */}
      <main className="w-full max-w-5xl flex flex-col items-center z-10">
        
        {/* Intro / Empty State */}
        {!currentPrompt && !isGeneratingText && (
          <div className="text-center max-w-2xl mb-12 animate-in fade-in zoom-in duration-500 flex flex-col items-center">
            <h2 className="text-6xl md:text-8xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-700 mb-6 brand-font leading-none">
              DARE TO<br />JUMP?
            </h2>
            <p className="text-zinc-400 text-lg mb-8 max-w-md mx-auto">
              Generate terrifying, high-stakes parkour scenarios powered by AI. 
              Witness the impossible gaps and vertigo-inducing heights.
            </p>
            
            <div className="w-full max-w-md mb-4 relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-zinc-500 w-5 h-5" />
              <input 
                type="text" 
                value={customInput}
                onChange={(e) => setCustomInput(e.target.value)}
                placeholder="Where to? (e.g. 'Eiffel Tower', 'Zombie Chase')"
                className="w-full bg-zinc-900 border border-zinc-700 text-white pl-10 pr-4 py-3 rounded-sm focus:ring-2 focus:ring-red-600 focus:border-transparent outline-none placeholder:text-zinc-600 font-mono text-sm transition-all"
                onKeyDown={(e) => e.key === 'Enter' && handleGeneratePrompt()}
              />
            </div>

            <button
              onClick={handleGeneratePrompt}
              className="w-full max-w-md group relative inline-flex items-center justify-center px-8 py-4 font-bold text-white transition-all duration-200 bg-red-600 font-mono rounded-sm hover:bg-red-700 hover:scale-[1.02] focus:outline-none ring-offset-2 focus:ring-2 ring-red-400"
            >
              <Zap className="w-5 h-5 mr-2 group-hover:animate-pulse" />
              GENERATE SCENARIO
            </button>
          </div>
        )}

        {/* Loading State for Prompt */}
        {isGeneratingText && (
          <div className="flex flex-col items-center justify-center h-64 animate-pulse">
            <div className="w-16 h-16 border-4 border-zinc-800 border-t-red-600 rounded-full animate-spin mb-4"></div>
            <p className="text-zinc-500 font-mono text-sm uppercase tracking-widest">
              {currentPrompt ? "Calculating Next Move..." : "Constructing Architecture..."}
            </p>
          </div>
        )}

        {/* Prompt Display */}
        {currentPrompt && !isGeneratingText && (
          <div className="w-full flex flex-col items-center animate-in slide-in-from-bottom-4 duration-500">
            <PromptCard 
              prompt={currentPrompt} 
            />

            {/* Action Buttons */}
            <div className="mt-8 flex flex-col sm:flex-row gap-4 w-full max-w-2xl justify-center">
              
               <button
                onClick={handleGenerateSequel}
                className="flex-1 group flex items-center justify-center px-6 py-4 font-bold text-black transition-all duration-200 bg-white font-mono rounded-sm hover:bg-zinc-200 focus:outline-none ring-offset-2 focus:ring-2 ring-white"
              >
                <FastForward className="w-5 h-5 mr-2 group-hover:translate-x-1 transition-transform" /> 
                CONTINUE RUN
              </button>

               <button
                onClick={handleReset}
                className="flex-1 group flex items-center justify-center px-6 py-4 font-bold text-white transition-all duration-200 bg-zinc-800 font-mono rounded-sm hover:bg-zinc-700 focus:outline-none ring-offset-2 focus:ring-2 ring-zinc-500"
              >
                <RefreshCw className="w-4 h-4 mr-2 group-hover:rotate-180 transition-transform duration-500" /> 
                NEW SCENARIO
              </button>
              
            </div>
          </div>
        )}

        {/* Error Display */}
        {error && (
          <div className="mt-8 p-4 bg-red-950/50 border border-red-900/50 text-red-200 rounded-lg max-w-md text-center text-sm">
            <p className="font-bold mb-1">System Failure</p>
            {error}
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="w-full text-center py-8 mt-auto z-10 border-t border-zinc-900/50">
         <p className="text-zinc-700 text-xs">
           CAUTION: EXPERT USE ONLY. DO NOT ATTEMPT IN REAL LIFE.
         </p>
      </footer>

    </div>
  );
};

export default App;